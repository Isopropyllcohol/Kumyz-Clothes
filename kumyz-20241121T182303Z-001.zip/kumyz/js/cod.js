// Simulación de un carrito de compras
let cart = [];

// Función para agregar un producto al carrito
function addToCart(productName, productPrice, productQuantity) {
    const cartItem = {
        name: productName,
        price: productPrice,
        quantity: productQuantity
    };

    // Verificar si el producto ya está en el carrito
    const existingItem = cart.find(item => item.name === productName);
    if (existingItem) {
        existingItem.quantity += productQuantity; // Incrementa la cantidad si ya existe
    } else {
        cart.push(cartItem); // Agrega el nuevo producto si no existe en el carrito
    }

    updateCart();
    showNotification();
}

// Función para actualizar el contenido del carrito
function updateCart() {
    const cartItemsContainer = document.getElementById('cart-items');
    cartItemsContainer.innerHTML = '';
    let total = 0;

    cart.forEach(item => {
        total += item.price * item.quantity;
        const cartItemElement = document.createElement('div');
        cartItemElement.classList.add('cart-item');
        cartItemElement.innerHTML = `
            <img src="../img/laufey.png" alt="${item.name}">
            <div class="cart-item-details">
                <div class="cart-item-name">${item.name}</div>
                <div class="cart-item-price">$${item.price.toFixed(2)}</div>
            </div>
            <div class="cart-item-quantity">
                <span>Cantidad: ${item.quantity}</span>
                <input type="number" min="1" value="${item.quantity}" onchange="updateQuantity(${cart.indexOf(item)}, this.value)">
            </div>
        `;
        cartItemsContainer.appendChild(cartItemElement);
    });

    document.getElementById('cart-total').innerText = `Total: $${total.toFixed(2)}`;
}

// Función para actualizar la cantidad de un producto en el carrito
function updateQuantity(index, quantity) {
    cart[index].quantity = parseInt(quantity);
    updateCart();
}

// Función para mostrar una notificación de que el producto ha sido añadido al carrito
function showNotification() {
    const notification = document.getElementById('notification');
    notification.style.display = 'block';
    setTimeout(() => {
        notification.style.display = 'none';
    }, 2000);
}

// Ejemplo de cómo conectar la función addToCart al botón de "Añadir al Carrito"
document.querySelector('.add-to-cart').addEventListener('click', () => {
    const productName = document.querySelector('.product-info h2').innerText;
    const productPrice = parseFloat(document.querySelector('.product-info .cart-item-price').innerText.replace('$', ''));
    const productQuantity = parseInt(document.getElementById('quantity').value);

    addToCart(productName, productPrice, productQuantity);
});
const prevBtn = document.getElementById('prevBtn');
const nextBtn = document.getElementById('nextBtn');
const slides = document.querySelectorAll('.slider-item');
const currentSlideText = document.getElementById('currentSlide');
const totalSlidesText = document.getElementById('totalSlides');

let currentSlide = 0;
const totalSlides = slides.length;

totalSlidesText.textContent = totalSlides;

function updateSlider() {
    slides.forEach((slide, index) => {
        slide.classList.remove('active');
        if (index === currentSlide) {
            slide.classList.add('active');
        }
    });
    currentSlideText.textContent = currentSlide + 1;
}

nextBtn.addEventListener('click', () => {
    currentSlide = (currentSlide + 1) % totalSlides;
    updateSlider();
});

prevBtn.addEventListener('click', () => {
    currentSlide = (currentSlide - 1 + totalSlides) % totalSlides;
    updateSlider();
});

// Inicialización del slider
updateSlider();

